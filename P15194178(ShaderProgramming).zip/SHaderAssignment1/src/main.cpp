#include <GL/glew.h>
#include <GLFW\glfw3.h> 

#include <iostream>
#include <fstream>
#include <string>
#include <sstream>

#include "Renderer.h"

#include "IndexBuffer.h"
#include "VertexBuffer.h"
#include "VertexBufferLayout.h"
#include "VertexArray.h"
#include "Shader.h"
#include "Texture.h"

#include "glm\glm.hpp"
#include "glm\gtc\matrix_transform.hpp"


int main(void)
{
	GLFWwindow* window;

	/* Initialize the library */
	if (!glfwInit())
		return -1;

	glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 4);
	glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 1);
	glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE);
	glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

	/* Create a windowed mode window and its OpenGL context */
	window = glfwCreateWindow(1000, 700, "OpenGl", NULL, NULL);
	if (!window)
	{
		glfwTerminate();
		return -1;
	}

	/* Make the window's context current */
	glfwMakeContextCurrent(window);

	glfwSwapInterval(1);

	if (glewInit() != GLEW_OK)
		std::cout << "Error!" << std::endl;

	// initializing buffer and setting data for drawing shape with OpenGL...
	// Declaring the Vertex data...
	std::cout << glGetString(GL_VERSION) << std::endl;
	{
		// vertex positions...
		float positions[] = {
		   -0.5f, -0.5f, 0.0f, 0.0f, // 0
			0.5f, -0.5f, 1.0f, 0.0f, // 1
			0.5f,  0.5f, 1.0f, 1.0f, // 2
		   -0.5f,  0.5f, 0.0f, 1.0f  // 3

		   -0.5f, -0.5f, 0.0f, 0.0f, // 4
			0.5f, -0.5f, 1.0f, 0.0f, // 5
			0.5f,  0.5f, 1.0f, 1.0f, // 6
		   -0.5f,  0.5f, 0.0f, 1.0f  // 7

		   -0.5f,  0.5f, 0.0f, 0.0f, // 8
		   -0.5f,  0.5f, 1.0f, 0.0f, // 9
		   -0.5f, -0.5f, 1.0f, 1.0f, // 10
		   -0.5f, -0.5f, 0.0f, 1.0f  // 11

		   -0.5f, -0.5f, 0.0f, 0.0f, // 12
			0.5f, -0.5f, 1.0f, 0.0f, // 13
			0.5f,  0.5f, 1.0f, 1.0f, // 14
		   -0.5f,  0.5f, 0.0f, 1.0f  // 15

		   -0.5f, -0.5f, 0.0f, 0.0f, // 16
			0.5f, -0.5f, 1.0f, 0.0f, // 17
			0.5f,  0.5f, 1.0f, 1.0f, // 18
		   -0.5f,  0.5f, 0.0f, 1.0f  // 19

		   -0.5f, -0.5f, 0.0f, 0.0f, // 20
			0.5f, -0.5f, 1.0f, 0.0f, // 21
			0.5f,  0.5f, 1.0f, 1.0f, // 22
		   -0.5f,  0.5f, 0.0f, 1.0f  // 23
		};

		// details of order to draw vertex to screen with out use of duplicate memory data...
		unsigned int indices[] =
		{
			0, 1, 2,
			2, 3, 0,

			4, 5, 6,
			6, 7, 4,

			8, 9, 10,
			10, 11, 8,

			12, 13, 14,
			14, 15, 12,

			16, 17, 18,
			18, 19, 16,

			20, 21, 22,
			22, 23, 20
		};

		// Blend Function...
		GLCall(glEnable(GL_BLEND));
		GLCall(glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA));

		// Vertex Buffer... (CLASS)
		VertexArray va;
		VertexBuffer vb(positions, 4 * 4 * sizeof(float));

		VertexBufferLayout layout;
		layout.Push<float>(2);
		layout.Push<float>(2);
		va.AddBuffer(vb, layout);

		// Index Buffer... (CLASS)
		IndexBuffer ib(indices, 6);

		// Boundris of window... (ideally in glm perspective to allow for 3d view...
		glm::mat4 proj = glm::ortho(-2.0f, 2.0f, -1.5f, 1.5f, -1.0f, 1.0f);

		Shader shader("Res/Shaders/Basic.shader");
		shader.Bind();
		shader.SetUniform4f("u_Color", 1.0f, 0.0f, 0.0f, 1.0f);
		shader.SetUniformMat4f("u_MVP", proj);

		// Load texture from the file path location...
		Texture texture("Res/Textures/Positive_X.jpg");
		texture.Bind();
		shader.SetUniform1i("u_Texture", 0);


		va.Unbind();
		vb.Unbind();
		ib.Unbind();
		shader.Unbind();

		Renderer renderer;

		float r = 0.0f;
		float increment = 0.5f;

		/* Loop until the user closes the window */
		while (!glfwWindowShouldClose(window))
		{
			/* Render here */
			renderer.Clear();

			// Draw to window call...
			shader.Bind();
			shader.SetUniform4f("u_Color", r, 0.0f, 0.5f, 1.0f);

			renderer.Draw(va, ib, shader);

			//affects the flow & transition of color change of square...
			if (r > 1.0f)
				increment = -0.05f;
			else if (r < 0.0f)
				increment = 0.05f;

			r += increment;

			/* Swap front and back buffers */
			glfwSwapBuffers(window);

			/* Poll for and process events */
			glfwPollEvents();
		}

		glfwTerminate();
		return 0;
	}
}